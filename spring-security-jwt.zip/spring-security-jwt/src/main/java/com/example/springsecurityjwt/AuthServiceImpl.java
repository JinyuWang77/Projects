package com.example.springsecurityjwt;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import com.fasterxml.jackson.databind.introspect.AnnotatedClass.Creators;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;;

    @Override
    public UserDTO createUser(LoginDTO loginDTO) {
        User user = new User();
        user.setName(loginDTO.getUser());
        user.setEmail(loginDTO.getEmail());
        user.setPassword(new BCryptPasswordEncoder().encode(loginDTO.getPassword()));
        User createdUser=userRepository.save(user);
        UserDTO userDTO = new UserDTO();
        userDTO.setEmail(createdUser.getEmail());
        userDTO.setName(createdUser.getName());

        return userDTO;
    }

}
