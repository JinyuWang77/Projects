package com.example.springsecurityjwt;

import lombok.Data;

@Data
public class LoginDTO {

    
	private String name;
    private String email;
    private String password;
    
    
	public LoginDTO() {
		super();
	}


	public LoginDTO(String user, String email, String password) {
		super();
		this.name = user;
		this.email = email;
		this.password = password;
	}


	public String getUser() {
		return name;
	}


	public void setUser(String user) {
		this.name = user;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "LoginDTO [user=" + name + ", email=" + email + ", password=" + password + "]";
	}
	
	
	
    
}
