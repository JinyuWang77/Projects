package com.example.springsecurityjwt;


public interface AuthService {

  

	UserDTO createUser(LoginDTO loginDTO);
	
	

	
}
